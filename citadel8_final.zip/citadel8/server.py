"""Онлайн-магазин «Генацидная цитадель номер 8» — Flask + Access (.accdb).

Запуск:  python server.py   →  http://127.0.0.1:5000
База:    database.accdb рядом с server.py (или переменная окружения DB_PATH).
"""
import os
import re
import secrets
import time
from contextlib import contextmanager
from datetime import datetime
from functools import wraps

import pyodbc
from flask import (Flask, abort, flash, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMG_DIR = os.path.join(BASE_DIR, "static", "book_images")
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "database.accdb"))
CONN_STR = f"Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};Dbq={DB_PATH};"

BRAND = "Генацидная цитадель номер 8"
ROLE_ADMIN = "Админ"
ROLE_USER = "Покупатель"
ORDER_STATUSES = ["В работе", "Выполнен"]
IMAGE_EXT = ("jpg", "jpeg", "png", "webp")
HASH_PREFIXES = ("scrypt:", "pbkdf2:")
HAS_ACTIVE = True  # есть ли в [Товар] колонка Активен (определяется при старте)


def hash_pw(pwd):
    return generate_password_hash(pwd, method="pbkdf2:sha256")


def active_filter(prefix="t."):
    return f"({prefix}[Активен] IS NULL OR {prefix}[Активен] = True)" if HAS_ACTIVE else "1=1"


def _secret_key() -> str:
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    path = os.path.join(BASE_DIR, "secret.key")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(secrets.token_hex(32))
    with open(path, encoding="utf-8") as f:
        return f.read().strip()


app = Flask(__name__)  # статика только из ./static — база и код недоступны по URL
app.secret_key = _secret_key()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=3 * 1024 * 1024,
)


# ====================== БД ======================
@contextmanager
def db():
    """Соединение с коммитом при успехе и откатом при ошибке."""
    conn = pyodbc.connect(CONN_STR)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def last_id(cur, table, id_col):
    """ID только что вставленной строки (в рамках этого соединения)."""
    try:
        cur.execute("SELECT @@IDENTITY")
        val = cur.fetchone()[0]
        if val:
            return int(val)
    except pyodbc.Error:
        pass
    cur.execute(f"SELECT MAX({id_col}) FROM [{table}]")
    return int(cur.fetchone()[0])


def ensure_schema():
    """Идемпотентная подготовка структуры. Данные не удаляются."""
    with db() as conn:
        cur = conn.cursor()

        def ok(sql):
            try:
                cur.execute(sql)
                return True
            except pyodbc.Error:
                return False

        # 1. Логин / Пароль / Роль у покупателей
        if not ok("SELECT Логин, Пароль, Роль FROM [Покупатель] WHERE 1=0"):
            ok("ALTER TABLE [Покупатель] ADD COLUMN [Логин] TEXT(50)")
            ok("ALTER TABLE [Покупатель] ADD COLUMN [Пароль] TEXT(255)")
            ok("ALTER TABLE [Покупатель] ADD COLUMN [Роль] TEXT(50)")

        # 2. Поле пароля должно вмещать хеш (255 символов)
        try:
            cols = {r.column_name.lower(): r.column_size
                    for r in cur.columns(table="Покупатель")}
            if cols.get("пароль", 255) < 255:
                ok("ALTER TABLE [Покупатель] ALTER COLUMN [Пароль] TEXT(255)")
        except pyodbc.Error:
            pass

        # 3. Мягкое удаление книг (сохраняет историю заказов)
        if not ok("SELECT Активен FROM [Товар] WHERE 1=0"):
            ok("ALTER TABLE [Товар] ADD COLUMN [Активен] YESNO")
            ok("UPDATE [Товар] SET [Активен] = True")

        # 4. Открытые пароли → хеши
        cur.execute("SELECT id_user, Пароль FROM [Покупатель] WHERE Пароль IS NOT NULL")
        for uid, pwd in cur.fetchall():
            if pwd and not pwd.startswith(HASH_PREFIXES):
                cur.execute("UPDATE [Покупатель] SET Пароль = ? WHERE id_user = ?",
                            hash_pw(pwd), uid)


def detect_schema():
    global HAS_ACTIVE
    try:
        with db() as conn:
            conn.cursor().execute("SELECT Активен FROM [Товар] WHERE 1=0")
        HAS_ACTIVE = True
    except pyodbc.Error:
        HAS_ACTIVE = False
        print("[warn] колонка [Товар].Активен недоступна: удаление книг будет полным")


# ====================== Вспомогательное ======================
@app.template_filter("rub")
def rub(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    s = f"{v:,.0f}" if v == int(v) else f"{v:,.2f}"
    return s.replace(",", " ") + " ₽"


@app.template_filter("fmtdate")
def fmtdate(value):
    if isinstance(value, datetime):
        return value.strftime("%d.%m.%Y")
    return str(value or "—")[:10]


def cover_url(book_id):
    for ext in IMAGE_EXT:
        if os.path.exists(os.path.join(IMG_DIR, f"{book_id}.{ext}")):
            return url_for("static", filename=f"book_images/{book_id}.{ext}")
    return url_for("static", filename="book_images/default.jpg")


def sniff_image(head: bytes):
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return None


def safe_next(target):
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return url_for("catalog")


def fetch_books(cur, book_id=None):
    sql = """
        SELECT t.id_tov, t.Название, t.ISBN, t.Цена, t.Колво,
               a.ФИО, j.Название, i.Название, t.[Год издания]
        FROM (((([Товар] AS t
        LEFT JOIN [АвторТовар] AS ta ON t.id_tov = ta.id_tov)
        LEFT JOIN [Автор] AS a ON ta.id_aut = a.id_aut)
        LEFT JOIN [ЖанрТовар] AS jt ON t.id_tov = jt.id_tov)
        LEFT JOIN [Жанр] AS j ON jt.id_janr = j.id_janr)
        LEFT JOIN [Издательство] AS i ON t.id_izd = i.id_izd
        WHERE """ + active_filter("t.") + """
    """
    params = []
    if book_id is not None:
        sql += " AND t.id_tov = ?"
        params.append(book_id)
    sql += " ORDER BY t.id_tov"
    cur.execute(sql, params)

    books = {}
    for r in cur.fetchall():
        b = books.setdefault(r[0], {
            "id": r[0], "title": (r[1] or "").strip(), "isbn": r[2] or "—",
            "price": float(r[3] or 0), "stock": int(r[4] or 0),
            "authors": [], "genres": [],
            "publisher": r[7] or "—", "year": r[8] or "—",
            "cover": cover_url(r[0]),
        })
        author = (r[5] or "").strip()
        genre = (r[6] or "").strip()
        if author and author not in b["authors"]:
            b["authors"].append(author)
        if genre and genre not in b["genres"]:
            b["genres"].append(genre)
    out = []
    for b in books.values():
        b["author"] = ", ".join(sorted(b["authors"])) or "Не указан"
        b["genre"] = ", ".join(sorted(b["genres"])) or "Без жанра"
        del b["authors"], b["genres"]
        out.append(b)
    return out


# ====================== Безопасность ======================
@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = session.get("csrf")
        if not token or not secrets.compare_digest(token, request.form.get("csrf", "")):
            abort(400)


@app.context_processor
def inject():
    session.setdefault("csrf", secrets.token_hex(16))
    return dict(
        csrf=session["csrf"],
        brand=BRAND,
        is_admin=session.get("role") == ROLE_ADMIN,
        cur_login=session.get("login"),
        cur_role=session.get("role"),
    )


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    if request.endpoint in ("login", "register"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


def login_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "user_id" not in session:
            flash("Войдите или зарегистрируйтесь, чтобы оформить заказ")
            return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        if session.get("role") != ROLE_ADMIN:  # проверка прав на сервере
            abort(403)
        return f(*a, **k)
    return wrapper


FAILS = {}  # защита от подбора пароля: 5 ошибок за 5 минут


def throttled(key):
    now = time.time()
    FAILS[key] = [t for t in FAILS.get(key, []) if now - t < 300]
    return len(FAILS[key]) >= 5


def start_session(user_id, login, role):
    session.clear()
    session.update(user_id=user_id, login=login, role=role or ROLE_USER,
                   csrf=secrets.token_hex(16))


# ====================== Каталог ======================
@app.get("/")
def catalog():
    with db() as conn:
        books = fetch_books(conn.cursor())
    genres = sorted({g.strip() for b in books for g in b["genre"].split(",")})
    return render_template("catalog.html", books=books, genres=genres)


@app.get("/33.html")
def old_index():
    return redirect(url_for("catalog"), 301)


# ====================== Регистрация / вход ======================
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html", error=None, form={})

    f = {k: (request.form.get(k) or "").strip()
         for k in ("login", "fio", "address", "phone")}
    password = request.form.get("password") or ""
    password2 = request.form.get("password2") or ""

    def fail(msg, code=400):
        return render_template("register.html", error=msg, form=f), code

    if not f["fio"] or not f["address"] or not f["phone"]:
        return fail("Заполните ФИО, адрес и телефон")
    if len(re.sub(r"\D", "", f["phone"])) < 10:
        return fail("Укажите корректный телефон")
    if not re.fullmatch(r"[\w.\-@]{3,50}", f["login"]):
        return fail("Логин: 3–50 символов (буквы, цифры, . _ - @)")
    if len(password) < 6:
        return fail("Пароль от 6 символов")
    if password != password2:
        return fail("Пароли не совпадают")

    with db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id_user FROM [Покупатель] WHERE Логин = ?", f["login"])
        if cur.fetchone():
            return fail("Логин уже занят", 409)
        cur.execute(
            "INSERT INTO [Покупатель] (ФИО, [Адресс], Телефон, Логин, Пароль, Роль) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            f["fio"], f["address"], f["phone"], f["login"],
            hash_pw(password), ROLE_USER)
        uid = last_id(cur, "Покупатель", "id_user")
    start_session(uid, f["login"], ROLE_USER)
    return redirect(url_for("catalog"))


@app.route("/login", methods=["GET", "POST"])
def login():
    nxt = request.args.get("next") or request.form.get("next") or ""
    if request.method == "GET":
        return render_template("login.html", error=None, next=nxt)

    login_ = (request.form.get("login") or "").strip()
    password = request.form.get("password") or ""
    key = f"{request.remote_addr}|{login_.lower()}"
    if throttled(key):
        return render_template("login.html", next=nxt,
                               error="Слишком много попыток. Подождите 5 минут"), 429

    with db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id_user, Пароль, Роль FROM [Покупатель] WHERE Логин = ?", login_)
        row = cur.fetchone()
        good = False
        if row and row[1]:
            if row[1].startswith(HASH_PREFIXES):
                good = check_password_hash(row[1], password)
            elif secrets.compare_digest(row[1], password):  # старая запись без хеша
                good = True
                cur.execute("UPDATE [Покупатель] SET Пароль = ? WHERE id_user = ?",
                            hash_pw(password), row[0])
    if not good:
        FAILS.setdefault(key, []).append(time.time())
        return render_template("login.html", next=nxt,
                               error="Неверный логин или пароль"), 401

    FAILS.pop(key, None)
    start_session(row[0], login_, row[2])
    return redirect(safe_next(nxt))


@app.get("/login.html")
def old_login():
    return redirect(url_for("login"), 301)


@app.get("/register.html")
def old_register():
    return redirect(url_for("register"), 301)


@app.route("/logout", methods=["GET", "POST"])
def logout():
    session.clear()
    return redirect(url_for("catalog"))


# ====================== Заказ ======================
@app.route("/order/<int:id_tov>", methods=["GET", "POST"])
@login_required
def order(id_tov):
    with db() as conn:
        cur = conn.cursor()
        books = fetch_books(cur, id_tov)
        if not books:
            abort(404)
        book = books[0]
        cur.execute("SELECT ФИО, [Адресс], Телефон FROM [Покупатель] WHERE id_user = ?",
                    session["user_id"])
        p = cur.fetchone()
        profile = {"fio": p[0] or "", "address": p[1] or "", "phone": p[2] or ""} if p else {}

        if request.method == "GET":
            return render_template("order.html", book=book, form=profile, error=None, qty=1)

        form = {k: (request.form.get(k) or "").strip() for k in ("fio", "phone", "address")}
        try:
            qty = int(request.form.get("qty", "1"))
        except ValueError:
            qty = 0

        def fail(msg, code=400):
            return render_template("order.html", book=book, form=form,
                                   error=msg, qty=max(qty, 1)), code

        if not all(form.values()):
            return fail("Заполните все поля")
        if qty < 1 or qty > 20:
            return fail("Количество: от 1 до 20")
        if book["stock"] < qty:
            return fail(f"На складе только {book['stock']} экз.")

        # атомарное списание: не уйдём в минус при одновременных заказах
        cur.execute(
            "UPDATE [Товар] SET Колво = Колво - ? "
            "WHERE id_tov = ? AND Колво >= ? AND " + active_filter(""),
            qty, id_tov, qty)
        if cur.rowcount != 1:
            return fail("Том только что закончился", 409)

        total = book["price"] * qty  # цена берётся из БД, а не из формы
        cur.execute("UPDATE [Покупатель] SET ФИО = ?, [Адресс] = ?, Телефон = ? WHERE id_user = ?",
                    form["fio"], form["address"], form["phone"], session["user_id"])
        cur.execute(
            "INSERT INTO [Заказ] (id_user, [Номер заказа], [Дата создания], Статус, Сумма) "
            "VALUES (?, ?, ?, ?, ?)",
            session["user_id"], "ORD-000", datetime.now().strftime("%d.%m.%Y"),
            ORDER_STATUSES[0], total)
        id_order = last_id(cur, "Заказ", "id_order")
        cur.execute("UPDATE [Заказ] SET [Номер заказа] = ? WHERE id_order = ?",
                    f"ORD-{id_order:03d}", id_order)
        try:  # состав заказа (если структура таблицы отличается — заказ всё равно сохранится)
            cur.execute(
                "INSERT INTO [ПозицияЗаказа] (id_order, id_tov, Колво, Стоимость) "
                "VALUES (?, ?, ?, ?)", id_order, id_tov, qty, total)
        except pyodbc.Error as e:
            print(f"[warn] ПозицияЗаказа не записана: {e}")
    return redirect(url_for("catalog", payment="success"))


@app.get("/order.html")
def old_order():
    id_tov = request.args.get("id_tov") or request.args.get("id")
    if id_tov and id_tov.isdigit():
        return redirect(url_for("order", id_tov=int(id_tov)))
    return redirect(url_for("catalog"))


@app.get("/orders")
@login_required
def orders():
    with db() as conn:
        cur = conn.cursor()
        if session.get("role") == ROLE_ADMIN:
            cur.execute(
                "SELECT z.id_order, z.[Номер заказа], z.[Дата создания], z.Статус, z.Сумма, "
                "p.ФИО, p.Телефон FROM [Заказ] AS z LEFT JOIN [Покупатель] AS p "
                "ON z.id_user = p.id_user ORDER BY z.id_order DESC")
        else:
            cur.execute(
                "SELECT id_order, [Номер заказа], [Дата создания], Статус, Сумма, '', '' "
                "FROM [Заказ] WHERE id_user = ? ORDER BY id_order DESC",
                session["user_id"])
        rows = cur.fetchall()
    return render_template("orders.html", rows=rows, statuses=ORDER_STATUSES)


# ====================== Админ ======================
def _refs(cur):
    cur.execute("SELECT id_janr, Название FROM [Жанр] ORDER BY Название")
    genres = [(r[0], r[1]) for r in cur.fetchall()]
    cur.execute("SELECT id_izd, Название FROM [Издательство] ORDER BY Название")
    pubs = [(r[0], r[1]) for r in cur.fetchall()]
    return genres, pubs


@app.route("/admin/add", methods=["GET", "POST"])
@admin_required
def admin_add():
    with db() as conn:
        cur = conn.cursor()
        genres, pubs = _refs(cur)
        if request.method == "GET":
            return render_template("admin_add.html", genres=genres, pubs=pubs, form={})

        f = {k: (request.form.get(k) or "").strip() for k in
             ("title", "author", "isbn", "year", "price", "stock", "genre_id", "publisher_id")}

        def fail(msg):
            return render_template("admin_add.html", genres=genres, pubs=pubs,
                                   form=f, error=msg), 400

        try:
            year = int(f["year"])
            price = float(f["price"].replace(",", "."))
            stock = int(f["stock"])
            genre_id = int(f["genre_id"])
            pub_id = int(f["publisher_id"])
        except ValueError:
            return fail("Год, цена, количество, жанр и издательство — числа")
        if not f["title"] or not f["author"]:
            return fail("Укажите название и автора")
        if not 1000 <= year <= datetime.now().year + 1:
            return fail("Некорректный год издания")
        if price <= 0 or stock < 0:
            return fail("Цена должна быть больше 0, количество — не меньше 0")
        if genre_id not in {g[0] for g in genres} or pub_id not in {p[0] for p in pubs}:
            return fail("Выберите жанр и издательство из списка")

        ext = None
        cover = request.files.get("cover")
        data = b""
        if cover and cover.filename:
            data = cover.read()
            ext = sniff_image(data[:12])
            if not ext:
                return fail("Обложка: допустимы JPG, PNG, WEBP")

        cur.execute("SELECT id_aut FROM [Автор] WHERE ФИО = ?", f["author"])
        row = cur.fetchone()
        if row:
            id_aut = row[0]
        else:
            cur.execute("INSERT INTO [Автор] (ФИО) VALUES (?)", f["author"])
            id_aut = last_id(cur, "Автор", "id_aut")

        cur.execute(
            "INSERT INTO [Товар] (ISBN, Название, Цена, [Год издания], Колво, id_izd"
            + (", [Активен]) VALUES (?, ?, ?, ?, ?, ?, True)" if HAS_ACTIVE
               else ") VALUES (?, ?, ?, ?, ?, ?)"),
            f["isbn"] or None, f["title"], price, year, stock, pub_id)
        id_tov = last_id(cur, "Товар", "id_tov")
        cur.execute("INSERT INTO [АвторТовар] (id_aut, id_tov) VALUES (?, ?)", id_aut, id_tov)
        cur.execute("INSERT INTO [ЖанрТовар] (id_janr, id_tov) VALUES (?, ?)", genre_id, id_tov)

    if ext:
        os.makedirs(IMG_DIR, exist_ok=True)
        with open(os.path.join(IMG_DIR, f"{id_tov}.{ext}"), "wb") as fh:
            fh.write(data)
    flash(f"Том «{f['title']}» добавлен в каталог")
    return redirect(url_for("catalog"))


@app.post("/admin/edit/<int:id_tov>")
@admin_required
def admin_edit(id_tov):
    try:
        price = float((request.form.get("price") or "").replace(",", "."))
        stock = int(request.form.get("stock") or "")
        if price <= 0 or stock < 0:
            raise ValueError
    except ValueError:
        flash("Неверные значения цены или остатка")
        return redirect(url_for("catalog"))
    with db() as conn:
        conn.cursor().execute("UPDATE [Товар] SET Цена = ?, Колво = ? WHERE id_tov = ?",
                              price, stock, id_tov)
    flash("Данные тома обновлены")
    return redirect(url_for("catalog"))


@app.post("/admin/delete/<int:id_tov>")
@admin_required
def admin_delete(id_tov):
    # мягкое удаление: том исчезает из каталога, история заказов остаётся целой
    with db() as conn:
        cur = conn.cursor()
        if HAS_ACTIVE:
            cur.execute("UPDATE [Товар] SET [Активен] = False WHERE id_tov = ?", id_tov)
        else:
            try:
                cur.execute("DELETE FROM [АвторТовар] WHERE id_tov = ?", id_tov)
                cur.execute("DELETE FROM [ЖанрТовар] WHERE id_tov = ?", id_tov)
                cur.execute("DELETE FROM [Товар] WHERE id_tov = ?", id_tov)
            except pyodbc.Error:
                conn.rollback()
                flash("Нельзя удалить: том есть в заказах")
                return redirect(url_for("catalog"))
    flash("Том удалён из каталога")
    return redirect(url_for("catalog"))


@app.post("/admin/order/<int:id_order>/status")
@admin_required
def admin_order_status(id_order):
    status = request.form.get("status")
    if status not in ORDER_STATUSES:
        abort(400)
    with db() as conn:
        conn.cursor().execute("UPDATE [Заказ] SET Статус = ? WHERE id_order = ?",
                              status, id_order)
    return redirect(url_for("orders"))


# ====================== Ошибки ======================
def _error(code, title, text):
    return render_template("error.html", code=code, title=title, text=text), code


@app.errorhandler(400)
def e400(_):
    return _error(400, "Запрос отклонён", "Страница устарела. Обновите её и повторите действие.")


@app.errorhandler(403)
def e403(_):
    return _error(403, "Доступ запрещён", "Нужны права администратора.")


@app.errorhandler(404)
def e404(_):
    return _error(404, "Не найдено", "Такой страницы или тома нет.")


@app.errorhandler(pyodbc.Error)
def edb(e):
    print(f"[db error] {e}")
    return _error(503, "База данных недоступна", "Попробуйте позже.")


if __name__ == "__main__":
    ensure_schema()
    detect_schema()
    os.makedirs(IMG_DIR, exist_ok=True)
    # debug выключен: отладчик Werkzeug с host=0.0.0.0 позволяет выполнить код на сервере
    app.run(debug=False, host="127.0.0.1", port=5000)
