"""Миграция БД Access. Запуск: python migrate.py
Безопасна для повторного запуска: уже существующее пропускается.
Перед запуском сделайте копию .accdb."""
import pyodbc

import config

STEPS = [
    "CREATE TABLE users ("
    "id AUTOINCREMENT PRIMARY KEY, "
    "email TEXT(100) NOT NULL, "
    "pwd_hash TEXT(255) NOT NULL, "
    "user_role TEXT(10) NOT NULL)",
    "CREATE UNIQUE INDEX ux_users_email ON users (email)",
    "CREATE TABLE orders ("
    "id AUTOINCREMENT PRIMARY KEY, "
    "user_id LONG NOT NULL, "
    "book_id LONG NOT NULL, "
    "price CURRENCY, "
    "created DATETIME)",
    f"ALTER TABLE {config.BOOKS_TABLE} ADD COLUMN is_active YESNO",
    f"UPDATE {config.BOOKS_TABLE} SET is_active = True WHERE is_active IS NULL OR is_active = False",
]

if __name__ == "__main__":
    with pyodbc.connect(config.DB_CONN, autocommit=True) as conn:
        for sql in STEPS:
            try:
                conn.execute(sql)
                print("OK  ", sql[:60])
            except pyodbc.Error as e:
                print("SKIP", sql[:60], "->", e.args[-1][:80])
