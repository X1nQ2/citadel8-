import os
import secrets
from contextlib import contextmanager
from datetime import datetime
from functools import wraps

import pyodbc
from flask import (Flask, abort, flash, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

import config

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)


@contextmanager
def db():
    conn = pyodbc.connect(config.DB_CONN)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------- защита ----------
@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = session.get("csrf")
        if not token or request.form.get("csrf") != token:
            abort(400)


@app.context_processor
def inject():
    session.setdefault("csrf", secrets.token_hex(16))
    return dict(
        csrf=session["csrf"],
        is_admin=session.get("role") == "admin",
        user=session.get("email"),
    )


def login_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "uid" not in session:
            flash("Войдите, чтобы купить книгу")
            return redirect(url_for("login"))
        return f(*a, **k)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "uid" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            abort(403)
        return f(*a, **k)
    return wrapper


# ---------- каталог ----------
@app.get("/")
def catalog():
    with db() as c:
        books = c.execute(
            f"SELECT id, title, author, genre, stock, price, cover "
            f"FROM {config.BOOKS_TABLE} WHERE is_active = True ORDER BY id"
        ).fetchall()
    return render_template("catalog.html", books=books)


# ---------- авторизация ----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        pwd = request.form.get("password", "")
        if "@" not in email or len(email) > 100 or len(pwd) < 8:
            flash("Неверный email или пароль короче 8 символов")
            return render_template("register.html")
        with db() as c:
            if c.execute("SELECT 1 FROM users WHERE email = ?", email).fetchone():
                flash("Этот email уже зарегистрирован")
                return render_template("register.html")
            c.execute(
                "INSERT INTO users (email, pwd_hash, user_role) VALUES (?, ?, 'user')",
                email, generate_password_hash(pwd),
            )
        flash("Регистрация выполнена. Войдите.")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        with db() as c:
            u = c.execute(
                "SELECT id, pwd_hash, user_role FROM users WHERE email = ?", email
            ).fetchone()
        if u and check_password_hash(u.pwd_hash, request.form.get("password", "")):
            session.clear()
            session.update(uid=u.id, email=email, role=u.user_role,
                           csrf=secrets.token_hex(16))
            return redirect(url_for("catalog"))
        flash("Неверный email или пароль")
    return render_template("login.html")


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("catalog"))


# ---------- покупка ----------
@app.post("/buy/<int:book_id>")
@login_required
def buy(book_id):
    with db() as c:
        cur = c.execute(
            f"UPDATE {config.BOOKS_TABLE} SET stock = stock - 1 "
            f"WHERE id = ? AND stock > 0 AND is_active = True", book_id)
        if cur.rowcount != 1:
            flash("Нет в наличии")
        else:
            price = c.execute(
                f"SELECT price FROM {config.BOOKS_TABLE} WHERE id = ?", book_id
            ).fetchone()[0]
            c.execute(
                "INSERT INTO orders (user_id, book_id, price, created) VALUES (?, ?, ?, ?)",
                session["uid"], book_id, price, datetime.now())
            flash("Книга добавлена в заказ")
    return redirect(url_for("catalog"))


# ---------- админ ----------
@app.route("/admin/add", methods=["GET", "POST"])
@admin_required
def admin_add():
    if request.method == "POST":
        try:
            stock = int(request.form["stock"])
            price = float(request.form["price"].replace(",", "."))
        except (KeyError, ValueError):
            flash("Количество и цена должны быть числами")
            return render_template("admin_add.html")
        if stock < 0 or price < 0:
            flash("Значения не могут быть отрицательными")
            return render_template("admin_add.html")

        name = ""
        f = request.files.get("cover")
        if f and f.filename:
            ext = f.filename.rsplit(".", 1)[-1].lower()
            if ext not in config.ALLOWED_EXT:
                flash("Допустимы только png, jpg, jpeg, webp")
                return render_template("admin_add.html")
            os.makedirs(config.COVERS_DIR, exist_ok=True)
            name = f"{secrets.token_hex(6)}_{secure_filename(f.filename)}"
            f.save(os.path.join(config.COVERS_DIR, name))

        with db() as c:
            c.execute(
                f"INSERT INTO {config.BOOKS_TABLE} "
                f"(title, author, genre, stock, price, cover, is_active) "
                f"VALUES (?, ?, ?, ?, ?, ?, True)",
                request.form["title"].strip(), request.form["author"].strip(),
                request.form["genre"].strip(), stock, price, name)
        flash("Том добавлен")
        return redirect(url_for("catalog"))
    return render_template("admin_add.html")


@app.post("/admin/delete/<int:book_id>")
@admin_required
def admin_delete(book_id):
    with db() as c:
        c.execute(f"UPDATE {config.BOOKS_TABLE} SET is_active = False WHERE id = ?",
                  book_id)
    flash("Том удалён из каталога")
    return redirect(url_for("catalog"))


@app.post("/admin/edit/<int:book_id>")
@admin_required
def admin_edit(book_id):
    try:
        stock = int(request.form["stock"])
        price = float(request.form["price"].replace(",", "."))
        if stock < 0 or price < 0:
            raise ValueError
    except (KeyError, ValueError):
        flash("Неверные значения остатка или цены")
        return redirect(url_for("catalog"))
    with db() as c:
        c.execute(
            f"UPDATE {config.BOOKS_TABLE} SET stock = ?, price = ? WHERE id = ?",
            stock, price, book_id)
    flash("Данные тома обновлены")
    return redirect(url_for("catalog"))


if __name__ == "__main__":
    os.makedirs(config.COVERS_DIR, exist_ok=True)
    app.run(debug=False)
