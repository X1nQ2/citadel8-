import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Путь к вашей базе Access. Можно задать переменной окружения DB_PATH.
DB_PATH = os.environ.get("DB_PATH", r"C:\path\to\base.accdb")

DB_CONN = (
    r"Driver={Microsoft Access Driver (*.mdb, *.accdb)};"
    rf"DBQ={DB_PATH};"
)

# Имена таблицы и колонок каталога. Поправьте под свою БД.
BOOKS_TABLE = "books"

COVERS_DIR = os.path.join(BASE_DIR, "static", "covers")
ALLOWED_EXT = {"png", "jpg", "jpeg", "webp"}


def _secret_key() -> str:
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    path = os.path.join(BASE_DIR, "secret.key")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(secrets.token_hex(32))
    with open(path, encoding="utf-8") as f:
        return f.read().strip()


SECRET_KEY = _secret_key()
