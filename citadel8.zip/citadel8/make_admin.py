"""Выдать роль администратора. Запуск: python make_admin.py user@mail.ru"""
import sys

import pyodbc

import config

if len(sys.argv) != 2:
    sys.exit("Использование: python make_admin.py email")

email = sys.argv[1].strip().lower()
with pyodbc.connect(config.DB_CONN, autocommit=True) as conn:
    n = conn.execute(
        "UPDATE users SET user_role = 'admin' WHERE email = ?", email
    ).rowcount
print("Готово: админ назначен" if n else "Пользователь не найден. Сначала зарегистрируйтесь.")
